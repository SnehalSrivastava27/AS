#include <iostream>
#include <cstring>
using namespace std;

void KMPCalcFailure(char P[], int m, int f[]) {
    int i = 1;   // position in pattern we are computing f(i) for
    int j = 0;   // length of longest prefix matched so far

    f[0] = 0;    // f(0) = 0

    while (i < m) {
        if (P[j] == P[i]) {
            // match of j+1 characters
            j = j + 1;
            f[i] = j;
            i = i + 1;
        }
        else if (j > 0) {
            // fall back to f(j−1)
            j = f[j - 1];
        }
        else {
            // no match and j == 0
            f[i] = 0;
            i = i + 1;
        }
    }
}

int KMPMatch(char T[], int n, char P[], int m, int f[]) {
    KMPCalcFailure(P, m, f);   // compute failure function

    int i = 0;   // index for T (text)
    int j = 0;   // index for P (pattern)

    while (i < n) {
        if (P[j] == T[i]) {
            if (j == m - 1) {
                // match found
                return i - m + 1;  
            }
            i = i + 1;
            j = j + 1;
        }
        else if (j > 0) {
            // fallback
            j = f[j - 1];
        }
        else {
            i = i + 1;
        }
    }

    return -1; // no match
}

int main() {
    char T[1000], P[1000];
    cout << "Enter text: ";
    cin >> T;
    cout << "Enter pattern: ";
    cin >> P;

    int n = strlen(T);
    int m = strlen(P);

    int f[1000];   // failure array

    int pos = KMPMatch(T, n, P, m, f);

    if (pos == -1)
        cout << "Pattern NOT found.\n";
    else
        cout << "Pattern found at index: " << pos << endl;

    return 0;
}