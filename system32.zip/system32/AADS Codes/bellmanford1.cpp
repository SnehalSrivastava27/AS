#include <iostream>
#include <limits>
using namespace std;

struct Edge {
    int u, v, w;
};

int main() {
    int n, m;
    cout << "Enter number of nodes and edges: ";
    cin >> n >> m;

    Edge edges[100];      // static array for edges (max 100 edges)

    cout << "Enter edges (u v w):\n";
    for (int i = 0; i < m; i++) {
        cin >> edges[i].u >> edges[i].v >> edges[i].w;
    }

    int s, t;
    cout << "Enter source (s) and target (t): ";
    cin >> s >> t;

    const int INF = 100000000;   // large value

    // M[i][v] table, up to 100 nodes
    int M[100][100];

    // Initialize M[0][v] = INF for all v
    for (int v = 0; v < n; v++) {
        M[0][v] = INF;
    }

    // M[0][t] = 0 as pseudocode says
    M[0][t] = 0;

    // For i = 1 ... n-1
    for (int i = 1; i < n; i++) {

        // Copy previous row
        for (int v = 0; v < n; v++) {
            M[i][v] = M[i - 1][v];
        }

        // Apply recurrence
        for (int k = 0; k < m; k++) {
            int u = edges[k].u;
            int v = edges[k].v;
            int w = edges[k].w;

            if (M[i - 1][v] != INF) {
                if (M[i - 1][v] + w < M[i][u]) {
                    M[i][u] = M[i - 1][v] + w;
                }
            }
        }
    }

    cout << "\nShortest distance from s to t = " 
         << M[n - 1][s] << endl;

    return 0;
}