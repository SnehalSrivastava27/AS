#include <iostream>
using namespace std;
#include <cstdlib>  
#include <ctime>   

int comparisons=0;
int Partition(int A[], int p, int r) {
    int x = A[r];   // pivot
    int i = p - 1;  
    
    if(p==r){
    	return r;
	}

    for (int j = p; j <= r - 1; j++) {
         comparisons++; // one comparison for A[j] <= x
        if (A[j] <= x) {
            i = i + 1;
            swap(A[i], A[j]);
            
        }
        
    }
    
    swap(A[i + 1], A[r]);  // put pivot in its correct place
    cout<<  A[i + 1];
    return i + 1;
}

int RandomizedPartition(int A[], int p, int r) {
    int i = p + rand() % (r - p + 1);  // random index between p and r
    cout << A[i] << endl;
    swap(A[r], A[i]);  // exchange pivot with A[r]
    return Partition(A, p, r);
}

int randomizedSelect(int A[], int p, int r, int i) {
    if (p == r)
        return A[p];

    int q = RandomizedPartition(A, p, r);
    int k = q - p + 1;

    if (i == k)
        return A[q];
    else if (i < k)
        return randomizedSelect(A, p, q - 1, i);
    else
        return randomizedSelect(A, q + 1, r, i - k);
}

int main() {
   
    int A[] = {6, 8, 2, 4, 7};
    int n = sizeof(A) / sizeof(A[0]);
    int i = 3; // 3rd smallest element

    int ans = randomizedSelect(A, 0, n - 1, i);

    cout << i << "rd smallest element is: " << ans << endl;
    cout << "Number of comparisons: " << comparisons << endl;

    return 0;
}
