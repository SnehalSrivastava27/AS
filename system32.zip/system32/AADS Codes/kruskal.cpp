#include <iostream>
#include <algorithm>
using namespace std;

const int MAXN= 20;
const int MAXM= 400;

class Edge{
public:
    int u, v, w;
};

bool compareEdges(const Edge& a, const Edge& b){
    return a.w<b.w;
}

Edge edges[MAXM];
int componentArr[MAXN + 1]; 
int setSizeArr[MAXN + 1];
Edge mstResult[MAXN-1]; 

int Find(int x){
    return componentArr[x];
}

void UnionSets(int rootA, int rootB, int n){
    if(setSizeArr[rootA] < setSizeArr[rootB]){
        swap(rootA, rootB);
    }
    for(int i=1; i<=n; i++){
        if(componentArr[i]==rootB){
            componentArr[i] =rootA;
        }
    }
    setSizeArr[rootA] +=setSizeArr[rootB];
}

int main(){

    int n, m;
    cout<<"enter the number of vertices and edges: ";
    cin>>n>>m;

    if(n<=0 || n>MAXN){
        cout<<"n is out of the range (1 to "<<MAXN<<")";
        return 1;
    }
    if(m<0 || m>MAXM){
        cout<<"m is out of the range (0 to "<<MAXM<<")";
        return 1;
    }

    cout<<"enter edge details (u v w):"<<endl;

    for(int i=0; i<m; i++){
        cin >> edges[i].u >> edges[i].v >> edges[i].w;
    }

    sort(edges, edges + m, compareEdges);

    for(int i=1; i<=n; i++){
        componentArr[i]= i;
        setSizeArr[i] =1;
    }

    int totalWeight =0;
    int edgesUsed =0;

    for(int i=0; i<m && edgesUsed<n-1; i++){
        int u= edges[i].u;
        int v= edges[i].v;

        int rootU= Find(u);
        int rootV= Find(v);

        if(rootU != rootV){
            UnionSets(rootU, rootV,n);
            totalWeight += edges[i].w;
            mstResult[edgesUsed] =edges[i];
            edgesUsed++;
        }
    }

    cout<<"total weight of MST: "<<totalWeight<<endl;
    cout<<"Edges in MST (u v w):"<<endl;
    for(int i=0; i<edgesUsed; i++){
        cout<<mstResult[i].u <<" "<< mstResult[i].v <<" "<< mstResult[i].w <<endl;
    }
    
    return 0;
}