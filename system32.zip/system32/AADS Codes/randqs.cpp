#include <iostream>
#include <cstdlib>  
#include <ctime>     

using namespace std;

int comparisons = 0;  // global counter for comparisons


int Partition(int A[], int p, int r) {
    int x = A[r];   // pivot
    int i = p - 1;  
    
    if(p==r){
    	return r;
	}

    for (int j = p; j <= r - 1; j++) {
         comparisons++; // one comparison for A[j] <= x
        if (A[j] <= x) {
            i = i + 1;
            swap(A[i], A[j]);
            
        }
        
    }
    
    swap(A[i + 1], A[r]);  // put pivot in its correct place
    return i + 1;
}

// Randomized-Partition
int Randomized_Partition(int A[], int p, int r) {
    int i = p + rand() % (r - p + 1);  // random index between p and r
    swap(A[r], A[i]);  // exchange pivot with A[r]
    return Partition(A, p, r);
}

// Randomized-Quicksort
void Randomized_Quicksort(int A[], int p, int r) {
    if (p < r) {
        int q = Randomized_Partition(A, p, r);
        Randomized_Quicksort(A, p, q - 1);
        Randomized_Quicksort(A, q + 1, r);
    }
}

int main() {

    int n;
    cout << "Enter number of elements: ";
    cin >> n;

    int* A = new int[n];  // dynamic array allocation

    cout << "Enter elements: ";
    for (int i = 0; i < n; i++) {
        cin >> A[i];
    }

    Randomized_Quicksort(A, 0, n - 1);

    cout << "Sorted array: ";
    for (int i = 0; i < n; i++) {
        cout << A[i] << " ";
    }
    cout << endl;

    cout << "Number of comparisons: " << comparisons << endl;

  
    return 0;
}

