#include <iostream>
using namespace std;

const int M = 4; // Max number of children per node

class BTreeNode {
public:
    bool leaf;
    int keyTally;
    int keys[M - 1];
    BTreeNode* pointers[M];

    BTreeNode(bool leaf = true) {
        this->leaf = leaf;
        keyTally = 0;
        for (int i = 0; i < M; i++) pointers[i] = nullptr; //pointers null because no children yet
    }
};

class BTree {
private:
    BTreeNode* root;

    BTreeNode* search(int K, BTreeNode* node) {
        if (!node) return nullptr;
        int i = 0;
        while (i < node->keyTally && K > node->keys[i]) i++;
        if (i < node->keyTally && K == node->keys[i])
            return node;
        if (node->leaf)
            return nullptr;
        return search(K, node->pointers[i]);
    }

    void splitChild(BTreeNode* parent, int i, BTreeNode* fullChild) {
        BTreeNode* newChild = new BTreeNode(fullChild->leaf);
        int mid = (M - 1) / 2;

        newChild->keyTally = (M - 1) - mid - 1;
        for (int j = 0; j < newChild->keyTally; j++) //keys set right child
            newChild->keys[j] = fullChild->keys[j + mid + 1];

        if (!fullChild->leaf) { //right child pointers set
            for (int j = 0; j <= newChild->keyTally; j++)
                newChild->pointers[j] = fullChild->pointers[j + mid + 1];
        }

        fullChild->keyTally = mid;

        for (int j = parent->keyTally; j > i; j--)
            parent->pointers[j + 1] = parent->pointers[j];
        parent->pointers[i + 1] = newChild;

        for (int j = parent->keyTally - 1; j >= i; j--)
            parent->keys[j + 1] = parent->keys[j];
        parent->keys[i] = fullChild->keys[mid]; //parent mein middle element
        parent->keyTally++;
    }

    void insertNonFull(BTreeNode* node, int K) {
        int i = node->keyTally - 1;
        if (node->leaf) {
            while (i >= 0 && K < node->keys[i]) {
                node->keys[i + 1] = node->keys[i];
                i--;
            }
            node->keys[i + 1] = K;
            node->keyTally++;
        } else {
            while (i >= 0 && K < node->keys[i]) i--;
            i++;
            if (node->pointers[i]->keyTally == M - 1) {
                splitChild(node, i, node->pointers[i]);
                if (K > node->keys[i]) i++;
            }
            insertNonFull(node->pointers[i], K);
        }
    }

    void traverse(BTreeNode* node) {
        if (!node) return;
        int i;
        for (i = 0; i < node->keyTally; i++) {
            if (!node->leaf) traverse(node->pointers[i]);
            cout << node->keys[i] << " ";
        }
        if (!node->leaf) traverse(node->pointers[i]);
    }

public:
    BTree() { root = nullptr; }

    bool search(int K) { return (search(K, root) != nullptr); }

    void insert(int K) {
        if (!root) {
            root = new BTreeNode(true);
            root->keys[0] = K;
            root->keyTally = 1;
            return;
        }

        if (root->keyTally == M - 1) {
            BTreeNode* newRoot = new BTreeNode(false);
            newRoot->pointers[0] = root;
            splitChild(newRoot, 0, root);
            root = newRoot;
        }

        insertNonFull(root, K);
    }

    void display() {
        traverse(root);
        cout << endl;
    }
};

int main() {
    BTree tree;
    int keys[] = {10, 20, 5, 6, 12, 30, 7, 17};
    for (int k : keys)
        tree.insert(k);

    cout << "B-tree contents (in order): ";
    tree.display();

    cout << "Searching 12: " << (tree.search(12) ? "Found" : "Not Found") << endl;
    cout << "Searching 99: " << (tree.search(99) ? "Found" : "Not Found") << endl;
}