#include <iostream>
using namespace std;

struct Node {
    Node* next[26];   // fixed alphabet: a–z

    Node() {
        for (int i = 0; i < 26; i++)
            next[i] = nullptr;
    }
};

// Build suffix trie according to the pseudocode
Node* buildSuffixTrie(const string &T) {
    int n = T.length();
    Node* root = new Node();

    for (int i = 0; i < n; i++) {   // for each starting position (suffix)
        Node* node = root;

        for (int j = i; j < n; j++) {  // insert characters T[i...n-1]
            int c = T[j] - 'a';

            if (node->next[c] == nullptr)
                node->next[c] = new Node();  // create new node

            node = node->next[c];
        }
    }
    return root;
}

int main() {
    string text = "banana";
    Node* root = buildSuffixTrie(text);

    cout << "Suffix Trie built successfully (no map, no vector)." << endl;
    return 0;
}
