#include <iostream>
#include <vector>
#include <limits>
using namespace std;

struct Edge {
    int u, v;
    int w;
};

int main() {
    int n, m;
    cout << "Enter number of vertices: ";
    cin >> n;

    cout << "Enter number of edges: ";
    cin >> m;

    vector<Edge> edges(m);

    cout << "Enter edges (u v weight):\n";
    for (int i = 0; i < m; i++) {
        cin >> edges[i].u >> edges[i].v >> edges[i].w;
    }

    int s;
    cout << "Enter source vertex: ";
    cin >> s;

    const int INF = numeric_limits<int>::max();

    // ----------------------------
    // Bellman-Ford using DP table M[i][v]
    // M[i][v] = shortest path from source s to v
    // using at most i edges
    // ----------------------------

    vector<vector<int>> M(n, vector<int>(n, INF));

    // Initialization
    M[0][s] = 0;

    // DP computation (like pseudocode)
    for (int i = 1; i < n; i++) {
        for (int v = 0; v < n; v++) {
            // Case 1: do not use new edge
            M[i][v] = M[i-1][v];

            // Case 2: try all edges (relaxation)
            for (auto &e : edges) {
                if (e.v == v && M[i-1][e.u] != INF) {
                    M[i][v] = min(M[i][v], M[i-1][e.u] + e.w);
                }
            }
        }
    }

    // Check for negative cycles
    bool negCycle = false;
    for (int v = 0; v < n; v++) {
        int oldVal = M[n-1][v];
        int newVal = oldVal;

        for (auto &e : edges) {
            if (e.v == v && M[n-1][e.u] != INF) {
                newVal = min(newVal, M[n-1][e.u] + e.w);
            }
        }

        if (newVal < oldVal) {
            negCycle = true;
            break;
        }
    }

    if (negCycle) {
        cout << "\nGraph contains a negative weight cycle.\n";
        return 0;
    }

    // Output shortest distances
    cout << "\nShortest distances from source " << s << ":\n";
    for (int v = 0; v < n; v++) {
        if (M[n-1][v] == INF)
            cout << "Vertex " << v << ": INF\n";
        else
            cout << "Vertex " << v << ": " << M[n-1][v] << "\n";
    }

    return 0;
}