#include <iostream>
#include <cstdlib>  
#include <ctime>    
using namespace std;

void swap(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
}

int partition(int A[], int p, int r) {
    int x = A[r]; 
    int i = p - 1;
    for (int j = p; j < r; j++) {
        if (A[j] <= x) {
            i++;
            swap(A[i], A[j]);
        }
    }
    swap(A[i + 1], A[r]);
    return i + 1;
}

int randomizedPartition(int A[], int p, int r) {
    int i = p + rand() % (r - p + 1);  
    swap(A[i], A[r]);
    return partition(A, p, r);
}

int randomizedSelect(int A[], int p, int r, int i) {
    if (p == r) {
        return A[p]; 
    }
    int q = randomizedPartition(A, p, r);
    int k = q - p + 1; 
    if (i == k) {
        return A[q];
    } else if (i < k) {
        return randomizedSelect(A, p, q - 1, i);
    } else {
        return randomizedSelect(A, q + 1, r, i - k);
    }
}

int main() {
    srand(time(0));  
    int A[] = {12, 3, 5, 7, 4};
    int n = sizeof(A) / sizeof(A[0]);
    int i;
    cout << "Enter i (1 <= i <= " << n << "): ";
    cin >> i;
    if (i < 1 || i > n) {
        cout << "Invalid i" << endl;
        return 0;
    }
    int result = randomizedSelect(A, 0, n - 1, i);
    cout << i << "th smallest element is: " << result << endl;
    return 0;
}