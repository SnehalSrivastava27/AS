#include <iostream>
#include <map>
#include <string>
using namespace std;

class TrieNode {
public:
    map<char, TrieNode*> children;

    TrieNode() {}
};

class SuffixTrie {
public:
    TrieNode* root;

    SuffixTrie() {
        root = new TrieNode();
    }

    void build(const string& T) {
        int n = T.size();

        // for i = |T|-1 downto 0
        for (int i = n - 1; i >= 0; i--) {
            TrieNode* node = root;
            int j = i;

            // While T[j]-edge exists:
            while (j < n && node->children.count(T[j])) {
                node = node->children[T[j]];
                j++;
            }

            // Now create nodes for the unmatched part T[j...n-1]
            for (int k = j; k < n; k++) {
                TrieNode* newNode = new TrieNode();
                node->children[T[k]] = newNode;
                node = newNode;
            }
        }
    }

    // Simple search function
    bool search(const string& P) {
        TrieNode* node = root;
        for (char c : P) {
            if (!node->children.count(c))
                return false;
            node = node->children[c];
        }
        return true;
    }
};

int main() {
    string T;
    cout << "Enter text: ";
    cin >> T;

    SuffixTrie st;
    st.build(T);

    cout << "Suffix Trie built successfully.\n";

    string pattern;
    cout << "Enter pattern to search: ";
    cin >> pattern;

    if (st.search(pattern))
        cout << "Pattern FOUND in text.\n";
    else
        cout << "Pattern NOT found.\n";

    return 0;
}