#include <iostream>
#include <queue>
using namespace std;

template <class T, int M>
class BTree;

template <class T, int M>
class BTreeNode {
public:
    bool leaf;
    int keyTally;
    T keys[M-1];
    BTreeNode<T, M>* children[M];

    BTreeNode(bool leaf = true) {
        this->leaf = leaf;
        keyTally = 0;
        for (int i = 0; i < M; i++)
            children[i] = nullptr;
    }

    friend class BTree<T, M>;
};

template <class T, int M>
class BTree {
private:
    BTreeNode<T, M>* root;

public:
    BTree() { root = nullptr; }

    // SEARCH OPERATION
    BTreeNode<T, M>* search(T K, BTreeNode<T, M>* node) {
        if (!node)
            return nullptr;

        int i = 0;

        while (i < node->keyTally && node->keys[i] < K)
            i++;

        if (i < node->keyTally && node->keys[i] == K)
            return node;

        if (node->leaf)
            return nullptr;

        return search(K, node->children[i]);
    }

    BTreeNode<T, M>* search(T K) {
        return search(K, root);
    }

    // SPLIT CHILD
    void splitChild(BTreeNode<T, M>* parent, int idx, BTreeNode<T, M>* fullChild) {
        int mid = (M - 1) / 2;

        BTreeNode<T, M>* newChild = new BTreeNode<T, M>(fullChild->leaf);
        newChild->keyTally = (M - 1) - mid - 1;

        for (int i = 0; i < newChild->keyTally; i++)
            newChild->keys[i] = fullChild->keys[mid + 1 + i];

        if (!fullChild->leaf) {
            for (int i = 0; i <= newChild->keyTally; i++)
                newChild->children[i] = fullChild->children[mid + 1 + i];
        }

        fullChild->keyTally = mid;

        for (int i = parent->keyTally; i >= idx + 1; i--)
            parent->children[i + 1] = parent->children[i];

        parent->children[idx + 1] = newChild;

        for (int i = parent->keyTally - 1; i >= idx; i--)
            parent->keys[i + 1] = parent->keys[i];

        parent->keys[idx] = fullChild->keys[mid];
        parent->keyTally++;
    }

    // INSERT NONFULL
    void insertNonFull(BTreeNode<T, M>* node, T K) {
        int i = node->keyTally - 1;

        if (node->leaf) {
            while (i >= 0 && node->keys[i] > K) {
                node->keys[i + 1] = node->keys[i];
                i--;
            }
            node->keys[i + 1] = K;
            node->keyTally++;
        } 
        else {
            while (i >= 0 && node->keys[i] > K)
                i--;
            i++;

            if (node->children[i]->keyTally == M - 1) {
                splitChild(node, i, node->children[i]);
                if (K > node->keys[i])
                    i++;
            }
            insertNonFull(node->children[i], K);
        }
    }

    // MAIN INSERT
    void insert(T K) {
        if (!root) {
            root = new BTreeNode<T, M>(true);
            root->keys[0] = K;
            root->keyTally = 1;
            return;
        }

        if (root->keyTally == M - 1) {
            BTreeNode<T, M>* newRoot = new BTreeNode<T, M>(false);
            newRoot->children[0] = root;

            splitChild(newRoot, 0, root);

            int i = 0;
            if (newRoot->keys[0] < K)
                i++;

            insertNonFull(newRoot->children[i], K);
            root = newRoot;
        }
        else {
            insertNonFull(root, K);
        }
    }

    // VISUALIZER
    void printTree() {
        if (!root) {
            cout << "Tree is empty.\n";
            return;
        }

        queue<BTreeNode<T, M>*> q;
        q.push(root);

        while (!q.empty()) {
            int levelSize = q.size();

            while (levelSize--) {
                BTreeNode<T, M>* node = q.front();
                q.pop();

                cout << "[ ";
                for (int i = 0; i < node->keyTally; i++)
                    cout << node->keys[i] << " ";
                cout << "]  ";

                if (!node->leaf) {
                    for (int i = 0; i <= node->keyTally; i++)
                        q.push(node->children[i]);
                }
            }
            cout << "\n";
        }
    }
};

int main() {
    BTree<int, 4> tree; // 4-way B-Tree (M = 4)

    tree.insert(10);
    tree.insert(20);
    tree.insert(5);
    tree.insert(6);
    tree.insert(12);
    tree.insert(30);
    tree.insert(7);
    tree.insert(17);

    cout << "B-Tree Visualization (Level Order):\n";
    tree.printTree();

    int key;
    cout << "\nSearch key: ";
    cin >> key;

    if (tree.search(key))
        cout << "Found\n";
    else
        cout << "Not Found\n";

    return 0;
}