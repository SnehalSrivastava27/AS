#include <bits/stdc++.h>
using namespace std;

vector<int> parent, rnk;
void make_set(int v) {
    parent[v] = v;
    rnk[v] = 0;
}

int find_set(int v) {
    if (v != parent[v])
        parent[v] = find_set(parent[v]);
    return parent[v];
}

void union_sets(int a, int b) {
    a = find_set(a);
    b = find_set(b);
    if (a != b) {
        if (rnk[a] < rnk[b])
            swap(a, b);
        parent[b] = a;
        if (rnk[a] == rnk[b])
            rnk[a]++;
    }
}

int main() {
    int n, m;
    cout << "Enter number of vertices and edges: ";
    cin >> n >> m;
    vector<vector<int>> edges(m, vector<int>(3));
    cout << "Enter edges (u v w):\n";
    for (int i = 0; i < m; i++) {
        cin >> edges[i][0] >> edges[i][1] >> edges[i][2];
    }
    sort(edges.begin(), edges.end(), [](auto &a, auto &b) {
        return a[2] < b[2];
    });
    parent.resize(n+1);
    rnk.resize(n+1);
    for (int v = 1; v <= n; v++) {
        make_set(v);
    }

    vector<vector<int>> mst;
    int mst_weight = 0;
    for (auto &e : edges) {
        int u = e[0], v = e[1], w = e[2];
        if (find_set(u) != find_set(v)) {
            mst.push_back(e);
            mst_weight += w;
            union_sets(u, v);
        }
    }
    cout << "\nMinimum Spanning Tree weight = " << mst_weight << "\n";
    cout << "Edges in MST:\n";
    for (auto &e : mst) {
        cout << e[0] << " - " << e[1] << " (" << e[2] << ")\n";
    }
    return 0;
}