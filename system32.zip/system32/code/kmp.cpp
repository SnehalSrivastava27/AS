#include <iostream>
#include <vector>
#include <string>
using namespace std;

vector<int> KMPFailureFunction(const string &P) {
    int m = P.length();
    vector<int> f(m);
    f[0] = 0;

    int j = 0; // prefix length

    for (int i = 1; i < m; i++) {
        while (j > 0 && P[i] != P[j])
            j = f[j - 1];

        if (P[i] == P[j])
            j++;

        f[i] = j;
    }
    return f;
}

// ------------------------------------------------------
// KMP Match Algorithm (follows your pseudocode exactly)
// ------------------------------------------------------
int KMPMatch(const string &T, const string &P) {
    int n = T.length();
    int m = P.length();

    vector<int> f = KMPFailureFunction(P);  // compute failure function

    int i = 0;   // index for T
    int j = 0;   // index for P

    while (i < n) {
        if (P[j] == T[i]) {
            if (j == m - 1)
                return i - m + 1;   // match found

            i++;
            j++;
        }
        else if (j > 0) {
            j = f[j - 1];            // shift using failure function
        }
        else {
            i++;
        }
    }

    return -1;   // no substring found
}

int main() {
    string T, P;

    cout << "Enter the text: ";
    getline(cin, T);

    cout << "Enter the pattern: ";
    getline(cin, P);

    int pos = KMPMatch(T, P);

    if (pos == -1)
        cout << "There is no substring of T matching P.\n";
    else
        cout << "Pattern found at index: " << pos << endl;

    return 0;
}