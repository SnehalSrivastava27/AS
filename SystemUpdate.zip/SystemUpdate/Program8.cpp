// Design a PDA and write a program for simulating the machine which accepts the language {wXwr
// | w is any string over S={a, b} and wr is reverse of that string and X is a special symbol }

#include <iostream>     // For input/output
#include <stack>        // Stack used for PDA memory
#include <string>       // For using string datatype
using namespace std;

// ---------------------------------------------------------------------------
// FUNCTION: PDA_wXwr
// PURPOSE : Simulates a PDA for the language { w X w^r }
//           where w is any string over {a, b}.
//
// PDA IDEA:
//   • Before X: push characters (this is w)
//   • After X : pop and match characters in reverse (this is w^r)
//
// Acceptance condition:
//   • Exactly ONE 'X' must appear
//   • Stack must be empty at the end
// ---------------------------------------------------------------------------

// X
// Accepted
// abbX
// Rejected
// abbXbba
// Accepted
// babaXabab
// Accepted

bool PDA_wXwr(const string &s) {

    stack<char> st;        // Stores characters of w
    bool seenX = false;    // Becomes true after encountering the single X

    for(char c : s) {

        // -----------------------------------------------------
        // Case 1: symbol is X (middle separator)
        // -----------------------------------------------------
        if(c == 'X') {

            // If X is seen more than once → invalid
            if(seenX)
                return false;

            seenX = true;   // Mark that the middle point is reached
        }

        // -----------------------------------------------------
        // Case 2: symbol is from alphabet {a, b}
        // -----------------------------------------------------
        else if(c == 'a' || c == 'b') {

            // BEFORE X → push characters (this forms w)
            if(!seenX) {
                st.push(c);
            }

            // AFTER X → pop and check reverse order (this checks w^r)
            else {
                // If stack empty OR mismatch → reject
                if(st.empty() || st.top() != c)
                    return false;

                st.pop();   // Matching character found → pop it
            }
        }

        // -----------------------------------------------------
        // Case 3: invalid character
        // -----------------------------------------------------
        else {
            return false;  // Reject any symbol not in {a, b, X}
        }
    }

    // -----------------------------------------------------
    // Accept only if:
    //   • X was present
    //   • Stack is empty (all characters matched in reverse)
    // -----------------------------------------------------
    return seenX && st.empty();
}

int main() {

    string s;
    while(cin >> s) {
        cout << (PDA_wXwr(s) ? "Accepted" : "Rejected") << endl;
    }

    return 0;
}


