// Design a Finite Automata (FA) that accepts language EVEN-EVEN over S={a, b}. Write a program
// to simulate this FA

#include <iostream>     // for input/output
#include <string>       // for string datatype
using namespace std;

// ---------------------------------------------------------------------------
// Function: evenEvenFA
// Purpose : Simulates a DFA for EVEN–EVEN language over Σ = {a, b}
//           Accept strings where:
//             → number of a's is even
//             → number of b's is even
//
// DFA STATES MEANING:
//   state 0 → even a, even b   (ACCEPT STATE)
//   state 1 → odd  a, even b
//   state 2 → even a, odd  b
//   state 3 → odd  a, odd  b
//
// On reading 'a' -> toggle parity of a-count
// On reading 'b' -> toggle parity of b-count
// ---------------------------------------------------------------------------
bool evenEvenFA(const string &s) {

    int state = 0;  
    // Start in state 0: (even a, even b)

    for(char c : s) {

        // If character is 'a', toggle the a-parity
        if(c == 'a') {
            if(state == 0) state = 1;   // even a → odd a
            else if(state == 1) state = 0;  // odd a → even a
            else if(state == 2) state = 3;  // even a, odd b → odd a, odd b
            else if(state == 3) state = 2;  // odd a, odd b → even a, odd b
        }

        // If character is 'b', toggle the b-parity
        else if(c == 'b') {
            if(state == 0) state = 2;   // even b → odd b
            else if(state == 2) state = 0;  // odd b → even b
            else if(state == 1) state = 3;  // odd a, even b → odd a, odd b
            else if(state == 3) state = 1;  // odd a, odd b → odd a, even b
        }

        // Invalid character
        else {
            return false;
        }
    }

    // Accept only if both counts are even → state 0
    return (state == 0);
}

int main() {

    string line;
    cout << "Enter string: ";

    // Keep reading strings until user stops
    while(cin >> line) {

        // Print ACCEPTED / REJECTED
        cout << (evenEvenFA(line) ? "ACCEPTED" : "REJECTED") << endl;
    }

    return 0;
}
