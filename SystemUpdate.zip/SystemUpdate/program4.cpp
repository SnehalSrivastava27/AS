// Design a Finite Automata (FA) that accepts language L2, over S= {a, b} where L2= a(a+b)*b. Write
// a program to simulate this FA.

#include <iostream>     // For input/output (cin, cout)
#include <string>       // For using string datatype
using namespace std;

// ---------------------------------------------------------------------------
// Function : startsWithAEndsWithB
// Purpose  : Simulates a Finite Automaton for the language L2 = a(a+b)*b
//            Conditions for acceptance:
//             → Must start with 'a'
//             → Must end with 'b'
//             → Middle part (a+b)* can contain ANY number of a’s or b’s
// ---------------------------------------------------------------------------
bool startsWithAEndsWithB(const string &s) {

    // Reject empty string immediately (it cannot start with 'a' and end with 'b')
    if(s.empty())
        return false;

    // Condition 1: First character must be 'a'
    if(s.front() != 'a')
        return false;

    // Condition 2: Last character must be 'b'
    if(s.back() != 'b')
        return false;

    // Condition 3: Check that every character is either 'a' or 'b'
    // This ensures the string belongs to Σ = {a, b}
    for(char c : s) {
        if(c != 'a' && c != 'b')
            return false;
    }

    // If all conditions are satisfied → string belongs to L2
    return true;
}

int main() {

    string line;
    cout << "Enter string: ";

    // Continuously read strings
    while(cin >> line) {

        // Print ACCEPTED (true) or REJECTED (false)
        cout << (startsWithAEndsWithB(line) ? "ACCEPTED" : "REJECTED") << endl;

    }

    return 0;
}
