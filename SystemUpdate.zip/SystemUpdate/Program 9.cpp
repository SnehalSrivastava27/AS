#include <iostream>
#include <string>
using namespace std;

bool TM_AnBnCn(string s){
    int i=0,n=s.size();
    while(1){
        while(i<n && s[i]=='X') i++;
        if(i==n) break;
        if(s[i]!='a') return false;
        s[i]='X';
        int j=i+1;
        while(j<n && s[j]=='X') j++;
        while(j<n && s[j]=='a') j++;
        if(j==n || s[j]!='b') return false;
        s[j]='Y';
        j++;
        while(j<n && (s[j]=='X'||s[j]=='Y'||s[j]=='a'||s[j]=='b')) j++;
        if(j==n || s[j]!='c') return false;
        s[j]='Z';
        i=0;
    }
    for(char c:s) if(c!='X'&&c!='Y'&&c!='Z') return false;
    return true;
}

int main(){
    string s;
    while(cin>>s) cout<<(TM_AnBnCn(s)?"Accepted":"Rejected")<<endl;
}

