// Design a Finite Automata (FA) that accepts all strings over S={0, 1} having three consecutive 1's as
// a substring. Write a program to simulate this FA.

#include <iostream>     // For input/output (cin, cout)
#include <string>       // To use C++ string datatype
using namespace std;

// ---------------------------------------------------------------------------
// Function: accepts_111
// Purpose : Simulates a Finite Automaton (FA) that accepts strings
//           containing "111" (three consecutive 1's) as a substring.
// Input   : A string of 0s and 1s.
// Output  : true  → string is ACCEPTED (contains "111")
//           false → string is REJECTED (does NOT contain "111")
// ---------------------------------------------------------------------------
bool accepts_111(const string &s) {

    int state = 0;  
    // state 0 → no '1' seen yet
    // state 1 → one '1' seen (i.e., substring "...1")
    // state 2 → two consecutive '1's seen (i.e., "...11")
    // state 3 → three consecutive '1's seen (i.e., "...111") ACCEPTING STATE

    // Loop through each character in the input string
    for(char c : s) {

        // Check: input should contain only 0 or 1
        if(c != '0' && c != '1')
            return false;   // Reject immediately if invalid symbol is found

        // Transition function of FA
        if(state == 0) {
            // From state 0: If we see '1', go to state 1.
            // If we see '0', remain in state 0.
            if(c == '1') state = 1;
            else state = 0;

        } else if(state == 1) {
            // From state 1: If we see another '1', go to state 2.
            // If we see '0', break the chain → return to state 0.
            if(c == '1') state = 2;
            else state = 0;

        } else if(state == 2) {
            // From state 2: If we see another '1', go to ACCEPTING state 3.
            // If we see '0', reset → state 0.
            if(c == '1') state = 3;
            else state = 0;

        } else {
            // state == 3
            // Already accepted "111". 
            // FA stays in state 3 no matter what comes next.
            state = 3;
        }
    }

    // Accept only if final state is 3
    return (state == 3);
}

// ---------------------------------------------------------------------------
// main() function
// Continuously reads input strings and prints ACCEPTED / REJECTED
// ---------------------------------------------------------------------------
int main() {

    string line;

    // Read input from user repeatedly until program is stopped
    while(cin >> line) {

        // Call FA simulation function and print the result
        if(accepts_111(line))
            cout << "ACCEPTED\n";
        else
            cout << "REJECTED\n";
    }
}
