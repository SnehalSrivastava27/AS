// Design a PDA and write a program for simulating the machine which accepts the language
// {a^nb^n where n>0, S= {a, b}}.

#include <iostream>     // For input/output
#include <stack>        // For using stack (PDA memory)
#include <string>       // For using string datatype
using namespace std;

// ---------------------------------------------------------------------------
// PDA_AnBn : Simulates a Pushdown Automaton (PDA) for language {a^n b^n | n>0}
// 
// PDA IDEA:
//   - Read a's first → for each 'a' push a symbol 'A' to stack
//   - After first 'b', switch to popping mode
//   - For each 'b' → pop one 'A'
//   - Accept if stack returns to bottom symbol '$' at the end
//
// STATE MEANING:
//   state 0 → reading a's (pushing A’s)
//   state 1 → reading b’s (popping A’s)
// ---------------------------------------------------------------------------

// ababababa
// Rejected
// aaabbb
// Accepted
// aaabbb
// Accepted

bool PDA_AnBn(const string &s) {

    if(s.empty()) 
        return false;   // Empty string is NOT allowed (n > 0 required)

    stack<char> st;
    st.push('$');       // Bottom-of-stack marker

    int state = 0;      // Start in state 0: pushing phase (read a's)

    for(char c : s) {

        // Reject if input contains anything other than 'a' or 'b'
        if(c != 'a' && c != 'b')
            return false;

        // -----------------------------
        //  STATE 0 → reading 'a's
        // -----------------------------
        if(state == 0) {

            if(c == 'a') {
                // For each 'a', push A onto stack
                st.push('A');
            }

            else { // c == 'b'
                // First 'b' encountered → switch to popping phase
                if(st.top() == 'A') {
                    st.pop();      // Pop matching 'A'
                    state = 1;     // Switch to b-phase (state 1)
                }
                else {
                    return false;  // If no 'A' to pop → invalid order
                }
            }
        }

        // -----------------------------
        //  STATE 1 → reading 'b's only
        // -----------------------------
        else { // state == 1

            if(c == 'a') 
                return false;      // No 'a' allowed after b-phase begins

            // For each 'b', pop one A
            if(st.top() == 'A')
                st.pop();
            else
                return false;      // No matching A → too many b's
        }
    }

    // ACCEPTANCE CONDITION:
    //  - Must be in state 1 (must have seen b’s)
    //  - Stack must be back to bottom symbol '$'
    return (state == 1 && st.top() == '$');
}

int main() {

    string s;
    while(cin >> s) {
        cout << (PDA_AnBn(s) ? "Accepted" : "Rejected") << endl;
    }

    return 0;
}
