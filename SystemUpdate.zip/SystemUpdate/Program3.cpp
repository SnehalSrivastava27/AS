// Design a Finite Automata (FA) that accepts language L1, over S={a, b}, comprising of all strings (of
// length 4 or more) having first two characters same as the last two. Write a program to simulate this
// FA.

#include <iostream>  
#include <string>       // For using string datatype
using namespace std;

// ---------------------------------------------------------------------------
// Function : program3
// Purpose  : Simulates a Finite Automaton that ACCEPTS strings over {a, b}
//            that:
//             → have length 4 or more
//             → AND whose first two characters are the SAME as the last two
// ---------------------------------------------------------------------------
bool program3(const string &s) {

    int n = s.size();   // Store length of string

    // Condition 1: string must be of length 4 or more
    // The problem says: "strings of length 4 or more"
    if(n < 4)
        return false;

    // Extract FIRST TWO characters: positions 0 and 1
    string first2 = s.substr(0, 2);

    // Extract LAST TWO characters: positions n-2 and n-1
    string last2 = s.substr(n - 2, 2);

    // Accept ONLY if first two characters match last two characters
    return (first2 == last2);
}

int main() {

    string line;
    cout << "Enter string: ";

    // Continuously read input strings
    while(cin >> line) {

        // Print ACCEPTED or REJECTED
        cout << (program3(line) ? "ACCEPTED" : "REJECTED") << endl;

    }

    return 0;
}
