// 6. Write a program to simulate an FA that accepts
// a. Union of the languages L1 and L2
// b. Intersection of the languages L1 and L2
// c. Language L1 L2 (concatenation)

#include <iostream>     // For input/output
#include <string>       // For using string datatype
using namespace std;

// ---------------------------------------------------------------------------
// FA1: Language L1 = { strings over {a, b} that contain AT LEAST ONE 'a' }
// ---------------------------------------------------------------------------
bool FA1(const string &s) {

    // Scan each character of the string
    for(char c : s) {
        if(c == 'a')
            return true;        // Accept immediately when we see at least one 'a'

        else if(c != 'b')
            return false;       // Reject if character is not from {a, b}
    }

    // If we never find 'a', reject
    return false;
}

// ---------------------------------------------------------------------------
// FA2: Language L2 = { strings over {a, b} that END WITH 'b' }
// ---------------------------------------------------------------------------
bool FA2(const string &s) {

    if(s.empty())
        return false;          // Empty string cannot end with 'b'

    // Check if all characters belong to alphabet {a, b}
    for(char c : s) {
        if(c != 'a' && c != 'b')
            return false;      // Reject if invalid symbol
    }

    // Accept only if last character is 'b'
    return s.back() == 'b';
}

// ---------------------------------------------------------------------------
// L1 ∪ L2 : UNION of languages
// ACCEPT if FA1 accepts OR FA2 accepts
// ---------------------------------------------------------------------------
bool FA_union(const string &s) {
    return FA1(s) || FA2(s);
}

// ---------------------------------------------------------------------------
// L1 ∩ L2 : INTERSECTION of languages
// ACCEPT if FA1 accepts AND FA2 accepts
// ---------------------------------------------------------------------------
bool FA_intersection(const string &s) {
    return FA1(s) && FA2(s);
}

// ---------------------------------------------------------------------------
// L1L2 : CONCATENATION of languages
//
// Idea:
// A string s belongs to L1L2 if we can split s into TWO parts:
//      s = x y
// where:
//      x ∈ L1   AND   y ∈ L2
//
// We try every possible split of the string.
// ---------------------------------------------------------------------------
bool FA_concatenation(const string &s) {

    // Try all split positions from 0 to s.size()
    for(size_t i = 0; i <= s.size(); i++) {

        string x = s.substr(0, i);    // First part (prefix)
        string y = s.substr(i);       // Second part (suffix)

        // If x satisfies L1 AND y satisfies L2 → ACCEPT
        if(FA1(x) && FA2(y))
            return true;
    }

    // If no valid split found → REJECT
    return false;
}

// ---------------------------------------------------------------------------
// MAIN FUNCTION
// Reads string and prints results of FA1, FA2, union, intersection, concatenation
// ---------------------------------------------------------------------------
int main() {

    string s;
    cout << "Enter string (over {a,b}): ";

    while(cin >> s) {

        cout << "\nFA1 (at least one 'a'): "
             << (FA1(s) ? "Accepted" : "Rejected") << endl;

        cout << "FA2 (ends with 'b'): "
             << (FA2(s) ? "Accepted" : "Rejected") << endl;

        cout << "Union (L1 ∪ L2): "
             << (FA_union(s) ? "Accepted" : "Rejected") << endl;

        cout << "Intersection (L1 ∩ L2): "
             << (FA_intersection(s) ? "Accepted" : "Rejected") << endl;

        cout << "Concatenation (L1L2): "
             << (FA_concatenation(s) ? "Accepted" : "Rejected") << endl;

        cout << "\nEnter string: ";
    }

    return 0;
}
