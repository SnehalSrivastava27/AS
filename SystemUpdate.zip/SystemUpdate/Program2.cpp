// Design a Finite Automata (FA) that accepts all strings over S={0, 1} having either exactly two 1's or
// exactly three 1's, not more nor less. Write a program to simulate this FA.

#include <iostream>     // For input/output (cin, cout)
#include <string>       // For using the string datatype
using namespace std;

// ---------------------------------------------------------------------------
// Function : program2
// Purpose  : Simulates a Finite Automaton that ACCEPTS strings over {0,1}
//            that contain EITHER:
//              → exactly TWO 1's
//              → exactly THREE 1's
//            and rejects all strings that have:
//              → fewer than 2 ones
//              → more than 3 ones
// ---------------------------------------------------------------------------
bool program2(const string &s) {

    int state = 0;
    // Here, 'state' is used to COUNT the number of 1's seen so far.
    // state = 0 → no 1's seen
    // state = 1 → one '1' seen
    // state = 2 → two '1's seen  (ACCEPTING)
    // state = 3 → three '1's seen (ACCEPTING)
    // More than 3 → REJECT immediately

    // Loop through each character of the string
    for(size_t i = 0; i < s.size(); i++) {

        // Check if the character is '1'
        if(s[i] == '1') {

            state++;      // Count the number of 1’s

            // If we have more than 3 ones → reject immediately.
            if(state > 3)
                return false;
        }

        // Note: If s[i] == '0', nothing happens. DFA remains in same state.
        // Because zeros do not affect the count of 1's.
    }

    // After scanning whole string:
    // Accept ONLY if number of 1's = 2 OR 3
    return (state == 2 || state == 3);
}

// ---------------------------------------------------------------------------
// main() function
// Continuously reads input and prints whether string is ACCEPTED or REJECTED
// ---------------------------------------------------------------------------
int main() {

    string line;
    cout << "Enter string: ";

    // Read strings repeatedly from input
    while(cin >> line) {

        // Call the FA simulation function and print true/false
        // true  → accepted
        // false → rejected
        cout << (program2(line) ? "ACCEPTED" : "REJECTED") << endl;

    }

    return 0;
}
