import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.neighbors import NearestNeighbors

data = pd.DataFrame({'values': [45,67,78,62,36,72,50,51,82,100]})


mean = data['values'].mean()
std = data['values'].std()

data['z_score'] = (data['values'] - mean) / std
data['is_outlier_z'] = data['z_score'].abs() > 1
print(data)


data = pd.DataFrame({'values': [45,67,29,91,50,62,36,72,85,150]})

Q1 = data['values'].quantile(0.25)
Q3 = data['values'].quantile(0.75)
IQR = Q3 - Q1

lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

data['is_outlier_iqr'] = (data['values'] < lower_bound) | (data['values'] > upper_bound)

print(data)
sns.boxplot(data['values'])

from sklearn.neighbors import NearestNeighbors

data = pd.DataFrame({'values': [10, 12, 12, 13, 12, 500, 14, 13, 11]})


X = data[['values']]

nbrs = NearestNeighbors(n_neighbors=3)
nbrs.fit(X)
distances, indices = nbrs.kneighbors(X)
data['knn_distance'] = distances[:, -1]
threshold = data['knn_distance'].mean() + 2 * data['knn_distance'].std()
data['is_outlier_knn'] = data['knn_distance'] > threshold
print(data)