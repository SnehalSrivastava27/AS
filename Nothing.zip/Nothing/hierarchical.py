import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_wine
from sklearn.cluster import AgglomerativeClustering
from scipy.spatial.distance import cdist
from scipy.cluster.hierarchy import dendrogram, linkage


wine = load_wine()
X = wine.data
y = wine.target

model = AgglomerativeClustering(n_clusters=3, linkage='single')
labels_sklearn = model.fit_predict(X)



def agglomerative_clustering(X, n_clusters=3):

    clusters = [[i] for i in range(len(X))]

    distances = cdist(X, X)
    np.fill_diagonal(distances, np.inf)

    while len(clusters) > n_clusters:

        min_dist = np.inf
        pair = (None, None)
        for i in range(len(clusters)):
            for j in range(i + 1, len(clusters)):

                dist = np.min([distances[p1, p2] for p1 in clusters[i] for p2 in clusters[j]])
                if dist < min_dist:
                    min_dist = dist
                    pair = (i, j)


        i, j = pair
        clusters[i].extend(clusters[j])
        del clusters[j]


    labels = np.zeros(len(X), dtype=int)
    for idx, cluster in enumerate(clusters):
        for point in cluster:
            labels[point] = idx

    return labels

labels_custom = agglomerative_clustering(X, n_clusters=3)


plt.figure(figsize=(15, 7))
plt.title('Hierarchical Clustering Dendrogram (Wine Dataset)', fontsize=16)


linkage_matrix = linkage(X, method='single')


dendrogram(
    linkage_matrix,
    truncate_mode='lastp',
    p=30,
    leaf_rotation=90.,
    leaf_font_size=10.,
    show_contracted=True,
)

plt.xlabel('Sample Index or (Cluster Size)', fontsize=12)
plt.ylabel('Distance', fontsize=12)
plt.tight_layout()
plt.show()



plt.show()