import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler

# ---------------------------
# Load inbuilt dataset (Iris)
# ---------------------------
data = load_iris()
X = data.data  # using first 2 features for plotting

# ---------------------------
# Standardize the dataset
# ---------------------------
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ---------------------------
# Apply K-Means
# ---------------------------
kmeans = KMeans(n_clusters=3, random_state=42)
labels = kmeans.fit_predict(X_scaled)

# ---------------------------
# Plot the Clusters
# ---------------------------
plt.scatter(
    X_scaled[:, 0],
    X_scaled[:, 1],
    c=labels,
    s=50
)

# Plot centroids
centers = kmeans.cluster_centers_
plt.scatter(
    centers[:, 0],
    centers[:, 1],
    c='red',
    s=200,
    marker='X',
    label='Centroids'
)

plt.title("K-Means Clustering on Iris Dataset")
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.legend()
plt.show()