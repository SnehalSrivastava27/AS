# corrected_adaboost_example.py
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import accuracy_score, precision_score, f1_score, confusion_matrix

# 1) Load data and split
data = load_wine()
X, y = data.data, data.target
class_names = data.target_names

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)

# 2) Define base estimator (this was missing in your code)
base_dt = DecisionTreeClassifier(max_depth=1, random_state=42)   # commonly used weak learner

# 3) Create AdaBoost with the defined base estimator
adaboost = AdaBoostClassifier(
    estimator=base_dt,     # ensure this variable exists (NameError fixed)
    n_estimators=50,
    learning_rate=0.8,
    random_state=42
)

# 4) Fit and predict
adaboost.fit(X_train, y_train)
y_pred_ada = adaboost.predict(X_test)

# 5) Metrics
acc_ada = accuracy_score(y_test, y_pred_ada)
prec_ada = precision_score(y_test, y_pred_ada, average='macro')
f1_ada = f1_score(y_test, y_pred_ada, average='macro')

print("\n=== ADABOOST CLASSIFIER ===")
print(f"Accuracy : {acc_ada:.4f}")
print(f"Precision: {prec_ada:.4f}")
print(f"F1-Score : {f1_ada:.4f}")

# 6) Confusion matrix plot
cm_ada = confusion_matrix(y_test, y_pred_ada)
plt.figure(figsize=(6, 4))
sns.heatmap(cm_ada, annot=True, cmap='Oranges', fmt='d',
            xticklabels=class_names, yticklabels=class_names)
plt.title("AdaBoost - Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.tight_layout()
plt.show()