from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier, AdaBoostClassifier, RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, f1_score, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
data = load_wine()
X = data.data
y = data.target
class_names = data.target_names

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# --------------------------
# DEFINE THE BASE ESTIMATOR
# --------------------------
base_dt = DecisionTreeClassifier(random_state=42)

# --------------------------
# BAGGING CLASSIFIER
# --------------------------
bagging = BaggingClassifier(
    estimator=base_dt,
    n_estimators=50,
    random_state=42
)

bagging.fit(X_train, y_train)
y_pred_bag = bagging.predict(X_test)

acc_bag = accuracy_score(y_test, y_pred_bag)
prec_bag = precision_score(y_test, y_pred_bag, average='macro')
f1_bag = f1_score(y_test, y_pred_bag, average='macro')

print("=== BAGGING CLASSIFIER ===")
print(f"Accuracy : {acc_bag:.4f}")
print(f"Precision: {prec_bag:.4f}")
print(f"F1-Score : {f1_bag:.4f}")

# Confusion matrix
cm_bag = confusion_matrix(y_test, y_pred_bag)
plt.figure(figsize=(5, 4))
sns.heatmap(
    cm_bag, annot=True, cmap='Blues', fmt='d',
    xticklabels=class_names, yticklabels=class_names
)
plt.title("Bagging - Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()