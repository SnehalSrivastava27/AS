import matplotlib.pyplot as plt
from sklearn.cluster import DBSCAN
from sklearn.datasets import make_blobs
from sklearn.preprocessing import StandardScaler

# isse hum random dataset banayenge
X, y_true = make_blobs(n_samples=300, centers=4, cluster_std=0.60, random_state=0)

# Standardize kr rhe random data ko
X = StandardScaler().fit_transform(X)

db = DBSCAN(eps=0.3, min_samples=10).fit(X)
labels = db.labels_

# ek saare point banadiye h jisme fir true kr rhe to mtlb wo core point fir db implement horha h
core_samples_mask = np.zeros_like(labels, dtype=bool)
core_samples_mask[db.core_sample_indices_] = True
# Count clusters and noise
n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
n_noise_ = list(labels).count(-1)

print(f"Estimated number of clusters: {n_clusters_}")
print(f"Estimated number of noise points: {n_noise_}")

plt.figure(figsize=(8, 6))

# Unique cluster ke saath loop cal rha
for cluster_id in set(labels):
    if cluster_id == -1:
        color = "black"
        label = "Noise"
    else:
        color = plt.cm.tab10(cluster_id % 10) #random color assign krne ka tarika
        label = f"Cluster {cluster_id}"

    
    cluster_points = X[labels == cluster_id]

    plt.scatter(cluster_points[:, 0], cluster_points[:, 1],
                s=50, color=color, label=label)

plt.title(f"DBSCAN Clustering (Clusters = {n_clusters_}, Noise = {n_noise_})")
plt.show()