import string
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS
from nltk.stem import PorterStemmer

# --- Short documents ---
docs = [
    "Machine learning helps computers learn from data.",
    "Data science uses machine learning for predictions.",
    "AI and machine learning improve decision making.",
    "Learning from data helps us find patterns."
]

# Initialize stemmer and stop words
stemmer = PorterStemmer()
stop_words = set(ENGLISH_STOP_WORDS)

def preprocess(text):
    # 1. lowercasing
    text = text.lower()

    # 2. remove punctuation
    text = text.translate(str.maketrans("", "", string.punctuation))

    # 3. tokenization
    words = text.split()

    # 4. remove stop words
    words = [w for w in words if w not in stop_words]

    # 5. stemming
    words = [stemmer.stem(w) for w in words]

    # return cleaned sentence
    return " ".join(words)

# preprocess all documents
clean_docs = [preprocess(doc) for doc in docs]

print("Processed Documents:\n")
for i, doc in enumerate(clean_docs, 1):
    print(f"Doc {i}: {doc}")
print("\n")

# TF-IDF (includes IDF)
vectorizer = TfidfVectorizer()
tfidf_matrix = vectorizer.fit_transform(clean_docs)

# get words and IDF values
words = vectorizer.get_feature_names_out()
idf_values = vectorizer.idf_

print("IDF Values (word : idf):\n")
for word, value in zip(words, idf_values):
    print(f"{word} : {value:.4f}")